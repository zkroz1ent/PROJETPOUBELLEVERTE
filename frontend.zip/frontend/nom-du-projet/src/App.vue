<template>
  <div id="app" class="min-h-screen bg-gray-100">
    <!-- Navbar sur toute la largeur en haut de la page -->
    <Navbarhome />

    <!-- Contenu principal de la page -->
    <router-view />
  </div>
</template>

<script>
// Importation de la Navbar
import Navbarhome from './components/Navbar.vue';

export default {
  name: 'App',
  components: {
    // Inscription de la Navbar dans les composants globaux
    Navbarhome,
  }
};
</script>

<style>
/* Ajouter des styles globaux ici si nécessaire */
</style>