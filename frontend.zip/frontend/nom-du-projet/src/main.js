import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';
import './assets/tailwind.css'; // Assurez-vous que le chemin vers le fichier est correct
createApp(App)
  .use(store)
  .use(router)
  .mount('#app');