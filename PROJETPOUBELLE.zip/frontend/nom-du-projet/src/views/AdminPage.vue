<template>
    <div>
      <AppNavbar />
      <h1>Welcome, Admin!</h1>
    </div>
  </template>
  
  <script>
  import AppNavbar from '@/components/AppNavbar.vue';
  
  export default {
    components: {
      AppNavbar
    }
  };
  </script>